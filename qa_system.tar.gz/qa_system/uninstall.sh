rm -rf stanford-corenlp-python
